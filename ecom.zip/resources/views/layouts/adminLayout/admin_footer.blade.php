

<!--Footer-part-->

<div class="row-fluid">
    <div id="footer" class="span12">  <a href="http://themedesigner.in"></a> </div>
</div>

<!--end-Footer-part-->