<?php $__env->startSection('content'); ?>

    <div id="content">
        <div id="content-header">
            <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">
                    Orders</a><a href="" class="current">View Orders</a>> </div>
            <h1>In Process Orders</h1>

            <!--display error message -->
            <?php if(Session::has('flash_message_error')): ?>
                <div class="alert alert-error alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong> <?php echo session('flash_message_error'); ?></strong>
                </div>
            <?php endif; ?>
        <!--display error message -->
            <?php if(Session::has('flash_message_success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong> <?php echo session('flash_message_success'); ?></strong>
                </div>
            <?php endif; ?>



        </div>
        <div class="container-fluid">
            <hr>
            <div class="row-fluid">
                <div class="span12">

                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>View Products</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <table class="table table-bordered data-table">
                                <thead>
                                <tr>
                                    <!--column names -->
                                    <th>Order ID</th>
                                    <th>Order Date</th>
                                    <th>Customer name</th>
                                    <th>Customer email</th>
                                    <th>Order Products</th>
                                    <th>Order Amount</th>
                                    

                                    <th>Order Status</th>
                                    

                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>





                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--$categories is our variable name in CategoryController inside our view
                                public function viewCategories(); and we use compact to pass it and our variable name is $categories-->
                                    <tr class="gradeX">
                                        <td><?php echo e($order->id); ?></td>
                                        <td>
                                            
                                            <?php echo e(date('F d, Y', strtotime($order->created_at))); ?>

                                        </td>
                                            <?php $__currentLoopData = $order->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <td><?php echo e($namee->f_name); ?> <?php echo e($namee->m_name); ?> <?php echo e($namee->l_name); ?></td>
                                        

                                        <td><?php echo e($namee->email); ?></td>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <td> <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php echo e($tt->product_name); ?> - <?php echo e($tt->pivot->quantity); ?> (qty) <br>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </td>




                                        <td><?php echo e($order->total_amount); ?></td>
                                        


                                        <td><?php echo e($order->order_status); ?></td>

                                        
                                        
                                        
                                        
                                        


                                        
                                        
                                        
                                        

                                        
                                        




                                        <td class="center">
                                            <a href="<?php echo e(url('/admin/view-order/'.$order->id )); ?>"  class="btn btn-success btn-mini">View</a>
                                            
                                            
                                            

                                            

                                            
                                            
                                            
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>