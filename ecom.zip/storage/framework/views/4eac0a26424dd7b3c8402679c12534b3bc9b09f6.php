<?php $__env->startSection('content'); ?>

    <div id="content">
        <div id="content-header">
            <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">
                    Categories</a><a href="" class="current">View Categories</a>> </div>
            <h1>Categories</h1>

            <!--display error message -->
            <?php if(Session::has('flash_message_error')): ?>
                <div class="alert alert-error alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong> <?php echo session('flash_message_error'); ?></strong>
                </div>
            <?php endif; ?>
        <!--display error message -->
            <?php if(Session::has('flash_message_success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong> <?php echo session('flash_message_success'); ?></strong>
                </div>
            <?php endif; ?>



        </div>
        <div class="container-fluid">
            <hr>
            <div class="row-fluid">
                <div class="span12">

                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>View Categories</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <table class="table table-bordered data-table">
                                <thead>
                                <tr>
                                    <!--column names -->
                                    <th>Category ID</th>
                                    <th>Category Name</th>
                                    <th>Category Level</th>
                                    <th>Category URL</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!--$categories is our variable name in CategoryController inside our view
                                public function viewCategories(); and we use compact to pass it and our variable name is $categories-->
                                <tr class="gradeX">
                                    <td><?php echo e($category->id); ?></td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->parent_id); ?></td>
                                    <td><?php echo e($category->url); ?></td>
                                    <td><?php echo e($category->status); ?></td>
                                    <td class="center">

                                        <a href="<?php echo e(url('/admin/edit-category/'.$category->id)); ?>" class="btn btn-primary btn-mini"><i class="icon-edit"></i></a>
                                        <!-- we inclue $category->id to pass id for the edit_category page -->

                                    <!-- <a id="#DEL_CAT" href="<?php/* <?php echo e(url('/admin/delete-category/'.$category->id)); ?>*/?> " class="btn btn-danger btn-mini">Delete</a>-->
                                <a id="DEL_CAT" rel="<?php echo e($category->id); ?>" rel1="delete-category" href="javascript:"  class="btn btn-danger btn-mini deleteRecord"><i class="icon-trash"></i></a>
                                        <!-- rel1 is our url -->


                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>