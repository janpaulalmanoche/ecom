<?php $__env->startSection('content'); ?>
    <section id="cart_items">
        <div class="container">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active">Paid Orders</li>
                </ol>
                <a href="<?php echo e(url('/orders-history')); ?>"><span style="color: orange; font-size: 17px;" ><p style="margin-top: -60px;">View New Orders</p></span></a>
            </div><!--/breadcrums-->


    <section id="do_action" style="margin-bottom: 250px;" >

    <div class="container">

        <div class="heading" align="center">

            <table id="example" class="table table-striped table-bordered" style="width:100%;">

                <thead>
                <tr>
                    <th>Refference No.</th>


                    
                    <th>Ordered Products</th>
                    <th> Price</th>

                    <th>Total</th>
                    <th>Order Date</th>
                    <th>Payment Date</th>
                    <th>Order Status</th>

                </tr>
                </thead>
                <tbody>
                <?php if($countORD > 0): ?>
                    <?php $total = 0;?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($order->refference_number); ?></td>


                            <td>
                                
                                
                                
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($pro->product_name); ?>


                               
                                <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                
                                
                                
                                <?php $__currentLoopData = $order->ordersz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <?php echo e($pro->price); ?> - (quantity-<?php echo e($pro->quantity); ?>)</br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>


                            <td> <?php echo e($order->total_amount); ?></td>
                            <td>
                                
                                <?php echo e(date('F d, Y', strtotime($order->created_at))); ?>

                            </td>
                            <td>

                                <?php echo e(date('F d, Y', strtotime($order->updated_at))); ?> |
                                |
                                <?php echo e(date('h:i A', strtotime($order->updated_at))); ?><br />
                                
                            <td><?php echo e($order->order_status); ?> </td>
                            <?php $total = $total + ($pro->price * $pro->quantity)?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php else: ?>

                                <h4> NO ORDERS</h4>
                            <?php endif; ?>

                        
                        </tr>
                </tbody>
            </table>

        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>