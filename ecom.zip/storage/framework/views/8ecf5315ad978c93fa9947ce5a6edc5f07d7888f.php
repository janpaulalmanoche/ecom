<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">  

    <title>Home | E-Shopper</title>



    <link href=" <?php echo e(asset('css/frontend_css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('css/frontend_css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('css/frontend_css/prettyPhoto.css')); ?> " rel="stylesheet">
    <link href=" <?php echo e(asset('css/frontend_css/price-range.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('css/frontend_css/animate.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('css/frontend_css/main.css')); ?>" rel="stylesheet">
    <link href=" <?php echo e(asset('css/frontend_css/responsive.css')); ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <script href="<?php echo e(asset('js/frontend_js/html5shiv.js')); ?>"></script>
    <script href="<?php echo e(asset('js/frontend_js/respond.min.js')); ?>"></script>
    <![endif]-->
    <link rel="shortcut icon" href="<?php echo e(asset('images/frontend_images/ico/favicon.ico')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('images/frontend_images/ico/apple-touch-icon-144-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('images/frontend_images/ico/apple-touch-icon-114-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('images/frontend_images/ico/apple-touch-icon-72-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('images/frontend_images/ico/apple-touch-icon-57-precomposed.png')); ?>">
</head><!--/head-->

<body>
<?php echo $__env->make('layouts.frontLayout.front_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.frontLayout.front_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="<?php echo e(asset('js/frontend_js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/jquery.scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/price-range.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/jquery.prettyPhoto.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/frontend_js/jquery.validate.js')); ?>"></script> <!-- for jquery or ajax validation file-->

</body>
</html>