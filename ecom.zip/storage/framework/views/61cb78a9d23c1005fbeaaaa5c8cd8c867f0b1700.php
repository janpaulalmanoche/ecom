<?php $__env->startSection('content'); ?>

    <section id="form" style="margin-top:30px;"><!--form-->
        <div class="container">
            <div class="row">
                <?php if(Session::has('flash_message_error')): ?>
                    <div class="alert alert-error alert-block"  style="background-color:#f2dfd0">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong> <?php echo session('flash_message_error'); ?></strong>
                    </div>
                <?php endif; ?>
            <!--display error message -->
                <?php if(Session::has('flash_message_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">x</button>
                        <strong> <?php echo session('flash_message_success'); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="col-sm-4 col-sm-offset-1" style="margin-left: 380px;" >
                    <div class="login-form">
                        <!--login form-->
                        <h2>Login to your account</h2>
                        <form id="loginForm" name="loginForm" method="post" action="<?php echo e(url('/user-login')); ?>"><?php echo e(csrf_field()); ?>

                            <input type="email" name="email" id="email" placeholder="Email Address" />
                            <input type="password" name="password" id="password" placeholder="Password" />
                            
								
								
							
                            <button type="submit" class="btn btn-default">Login</button>

                        </form></br>
                        <a href="<?php echo e(url('/user-registration')); ?>"> <p><span style="font-weight: bold; color: orange;">Create Account here</span></p></a>
                    </div><!--/login form-->
                </div>

                    
                
                    
                
                
                    
                        
                        
                            
                            
                            
                            
                            
                            
                        
                    
                

            </div>
        </div>
    </section><!--/form-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>