<?php $__env->startSection('content'); ?>

<!--main-container-part-->
<div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
    </div>
    <!--End-breadcrumbs-->

    <!--Action boxes-->
    <div class="container-fluid">

        <div class="quick-actions_homepage">
            <ul class="quick-actions">
                
                
                
                
                
                
                
                
                
                

            </ul>
        </div>
       <!--End-Action boxes-->

        <!--Chart-box-->
        <div class="row-fluid">
            <div class="widget-box">
                <div class="widget-title bg_lg"><span class="icon"><i class="icon-signal"></i></span>
                    <h5>Site Analytics</h5>



                </div>
                <div class="widget-content" >
                    <div class="row-fluid">
                        <div class="span9">
                            <div class="chart"><a href="<?php echo e(url('/')); ?>">Visit Front end</a></div>
                        </div>
                        <div class="span3">
                            <ul class="site-stats">
                                <li class="bg_lh"><a href="#"><i class="icon-user"></i> <strong><?php echo e($countUsers+1); ?></strong> <small>Total Users</small></a></li>
                                
                                <li class="bg_lh"><a href="#"><i class="icon-shopping-cart"></i> <strong><?php echo e($count); ?></strong> <small>New Orders</small></a></li>
                                <li class="bg_lh"><a href="#"><i class="icon-tag"></i> <strong><?php echo e($Totalorders); ?></strong> <small>Total Orders</small></a></li>
                                
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End-Chart-box-->
        <hr/>
        <div class="row-fluid">
            <div class="span6">

                <div class="widget-box">
                    <div class="widget-title bg_ly" data-toggle="collapse" href="#collapseG2"><span class="icon"><i class=""></i></span>
                        <h5>New Orders (<?php echo e($count); ?>)</h5>
                    </div>
                    <div class="widget-content nopadding fix_hgt" style="height: 500px;">
                        <ul class="recent-posts">
                            <?php $__currentLoopData = $NewOrdersDisplayinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $try2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $try2->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="user-thumb"> <i class="icon-user"></i></div>
                                <div class="article-post"> <span class="user-info"><?php echo e(date('F d, Y', strtotime($try2->updated_at))); ?> </span> <br> <?php echo e($gg->email); ?>

                                    <p><a href="#">New Order ( Reference Number #<?php echo e($try2->refference_number); ?> ).  View for more Details</a> </p>
                                </div>
                                <a href="<?php echo e(url('/admin/view-order/'.$try2->id)); ?>"> <button  class="btn-primary">View</button></a>
                            </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                            
                        </ul>
                    </div>
                </div>


           </div>
            <div class="span6">

                <div class="widget-box">
                    <div class="widget-title"><span class="icon"><i class=""></i></span>
                        <h5>Products with empty stocks</h5>
                    </div>
                    <div class="widget-content nopadding fix_hgt" style="height: 500px;">
                        <ul class="recent-posts">

                            <?php $__currentLoopData = $displayLowStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $try): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="user-thumb"> <img width="40" height="40" alt="User" src="<?php echo e(asset('/images/backend_images/products/small/'.$try->image)); ?>" style="height: 45px;width: 80px;"> </div>
                                <div class="article-post"> <span class="user-info"><?php echo e($try->product_name); ?></span>
                                    <p>Stocks Remaining ( <?php echo e($try->stock); ?> )</p>
                                    <a href="<?php echo e(url('/admin/view-add-stocks/'.$try->id)); ?>"> <button style="margin-top: 4px;" class="btn-primary">Add</button></a>
                                </div>
                            </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!--end-main-container-part-->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>