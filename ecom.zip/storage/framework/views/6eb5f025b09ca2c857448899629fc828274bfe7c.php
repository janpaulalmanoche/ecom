<?php $__env->startSection('content'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <section id="cart_items">
        <div class="container">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active">Check out</li>
                </ol>
            </div><!--/breadcrums-->

            
                
            
            
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
            

            
                
            

            <div class="shopper-informations">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="shopper-info">
                            
                            
                                
                                
                                
                                
                            
                            
                            
                        </div>
                    </div>


                    <div class="col-sm-5 clearfix" style="margin-top: -60px;">
                        <div class="bill-to">
                            <p>Bill To</p>
                            <div class="signup-form"x>

                                <form id="accountForm" name="accountForm" action="<?php echo e(url('/checkout')); ?>" method="post" ><?php echo e(csrf_field()); ?>


                                    Email <input id="name" style="width:320px;" name="email" type="text" placeholder="Email" value="<?php echo e($user_details->email); ?>">
                                    First Name<input id="name"  style="width:320px;"name="name" type="text" placeholder="First Name" value="<?php echo e($user_details->f_name); ?>">
                                    Middle Name<input id="mname"  style="width:320px;"name="m_name" type="text" placeholder="Middle Name" value="<?php echo e($user_details->m_name); ?>">
                                    Last Name<input id="name"  style="width:320px;"name="l_name" type="text" placeholder="Last Name" value="<?php echo e($user_details->l_name); ?>">

                                    City<select class="form-control input-lg dynamic" data-dependent="Baranggay" id="city" name="city" style="width:320px;height: 40px;background-color: whitesmoke;font-size: 15px;">
                                        <option value="select">Select City</option>
                                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            

                                            <option value="<?php echo e($li->City); ?>" <?php if($li->City == $user_details->city): ?> selected="" <?php endif; ?>>
                                                <?php echo e($li->City); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        

                                    </select>


                                    Baranggay<select class="form-control input-lg dynamic" id="Baranggay" name="baranggay" data-dependent="Street" style="width:320px;height: 40px;background-color: whitesmoke;font-size: 15px;">
                                        <option value="select">Select Baranggay</option>

                                    </select>

                                    Street<select class="form-control input-lg dynamic" id="Street" name="street" style="width:320px;height: 40px;background-color: whitesmoke;font-size: 15px;">
                                        <option value="select">Select Street</option>
                                    </select>


                                    Mobile #<input  style="width:320px;" id="mobile" name="mobile" type="text" placeholder="Mobile +63" value="<?php echo e($user_details->mobile); ?>">


                                    
                                        
                                        
                                            
                                                    
                                            
                                                
                                            
                                        
                                    




                                    <button type="submit" class="btn btn-default">Proceed</button>

                                </form>
                            </div>
                            <div class="form-two">
                                <form>

                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    


                                </form>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    <div class="col-sm-4">
                        <div class="order-message">
                            
                            
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="review-payment">
                <h2>Review </h2>
            </div>

            <div class="table-responsive cart_info">
                <table class="table table-condensed">
                    <thead>
                    <tr class="cart_menu">
                        <td class="image">Item</td>
                        <td class="description"></td>
                        <td class="price">Price</td>
                        <td class="quantity">Quantity</td>
                        <td class="total">Total</td>
                        <td></td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $total_amount = 0; ?>
                    <?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $cart->cartprod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="cart_product">
                                <a href=""><img style="width:100px;" src="<?php echo e(asset('images/backend_images/products/small/'.$cart->image)); ?>" alt=""></a>
                            </td>
                            <td class="cart_description">
                                <h4><a href=""><?php echo e($carts->product_name); ?></a></h4>
                                <p>Code:<?php echo e($carts->product_code); ?> | Size:<?php echo e($carts->size); ?> <?php echo e($carts->measurement); ?></p>

                            </td>
                            <td class="cart_price">
                                <p>P<?php echo e($carts->price); ?></p>
                            </td>
                            <td class="cart_quantity">
                                <div class="cart_quantity_button">
                                    <a class="cart_quantity_up" href="<?php echo e(url('/cart/update-quantity/'.$cart->id.'/1')); ?>"> + </a>
                                    <input class="cart_quantity_input" type="text"
                                           name="quantity" value="<?php echo e($cart->quantity); ?>" autocomplete="off" size="2">

                                    <?php if($cart->quantity>1): ?>
                                        <a class="cart_quantity_down" href="<?php echo e(url('/cart/update-quantity/'.$cart->id.'/-1')); ?>"> - </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="cart_total">
                                <p class="cart_total_price">PHP <?php echo e($carts->price*$cart->quantity); ?></p>
                                
                            </td>
                            <td class="cart_delete">
                                <a class="cart_quantity_delete" href="<?php echo e(url('/cart/delete-product/'.$cart->id)); ?>"><i class="fa fa-times"></i></a>
                            </td>
                        </tr>

                        <?php $total_amount = $total_amount + ($carts->price*$cart->quantity); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td colspan="4">&nbsp;</td>
                        <td colspan="2">
                            <table class="table table-condensed total-result">
                                
                                    
                                    
                                
                                
                                    
                                    
                                
                                
                                    
                                    
                                
                                <tr>
                                    <td>Total</td>
                                    <td><span>PHP<?php echo $total_amount; ?></span></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="payment-options">
					
						
					
                
						
					
                
						
					
            </div>
        </div>
    </section> <!--/#cart_items-->








    <script>
        $(document).ready(function(){

            $('.dynamic').change(function(){
                if($(this).val() != '')
                {
                    var select = $(this).attr("id");
                    var value = $(this).val();
                    var dependent = $(this).data('dependent');
                    var _token = $('input[name="_token"]').val();
                    $.ajax({
                        url:"<?php echo e(route('dynamicdependent.fetch3')); ?>",
                        method:"POST",
                        data:{select:select, value:value, _token:_token, dependent:dependent},
                        success:function(result)
                        {
                            $('#'+dependent).html(result);
                        }

                    })
                }
            });

            $('#city').change(function(){
                $('#Baranggay').val('');
                $('#Street').val('');
            });

            $('#Baranggay').change(function(){
                $('#Street').val('');
            });


        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>