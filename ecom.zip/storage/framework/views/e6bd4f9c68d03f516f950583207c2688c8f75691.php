

<footer id="footer"><!--Footer-->
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-sm-2">
                    <div class="companyinfo">
                        
                        
                    </div>
                </div>
                
                    
                        
                            
                                
                                    
                                
                                
                                    
                                
                            
                            
                            
                        
                    

                    
                        
                            
                                
                                    
                                
                                
                                    
                                
                            
                            
                            
                        
                    

                    
                        
                            
                                
                                    
                                
                                
                                    
                                
                            
                            
                            
                        
                    

                    
                        
                            
                                
                                    
                                
                                
                                    
                                
                            
                            
                            
                        
                    
                
                
                    
                        
                        
                    
                </div>
            </div>
        </div>
    </div>

    <div class="footer-widget">
        <div class="container">
            <div class="row">
                <div class="col-sm-2">
                    <div class="single-widget">
                        
                        
                            
                            
                            
                            
                            
                        
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="single-widget">
                        
                        
                            
                            
                            
                            
                            
                        
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="single-widget">
                        
                        
                            
                            
                            
                            
                            
                        
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="single-widget">
                        
                        
                            
                            
                            
                            
                            
                        
                    </div>
                </div>
                <div class="col-sm-3 col-sm-offset-1">
                    <div class="single-widget">
                        
                        
                            
                            
                            
                        
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <p class="pull-left">Copyright © 2013 E-SHOPPER Inc. All rights reserved.</p>
                <p class="pull-right">Designed by <span><a target="_blank" href="http://www.themeum.com">Themeum</a></span></p>
            </div>
        </div>
    </div>

</footer><!--/Footer-->