<?php $__env->startSection('content'); ?>


    <!--main-container-part-->
    <div id="content">
        <div id="content-header">
            <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#" class="current">Orders</a> </div>
            <h1>Refference No.<?php echo e($orders->refference_number); ?></h1>
            <!--display error message -->
            <?php if(Session::has('flash_message_error')): ?>
                <div class="alert alert-error alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong> <?php echo session('flash_message_error'); ?></strong>
                </div>
            <?php endif; ?>
        <!--display error message -->
            <?php if(Session::has('flash_message_success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong> <?php echo session('flash_message_success'); ?></strong>
                </div>
            <?php endif; ?>

        </div>
        <div class="container-fluid">
            <hr>
            <div class="row-fluid">
                <div class="span6">

                    <div class="widget-box">
                        <div class="widget-title">
                            <h5>Order Details</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <table class="table table-striped table-bordered">

                                <tbody>
                                <tr>
                                    <td class="taskDesc">Order ID</td>
                                    <td class="taskStatus"><?php echo e($orders->id); ?></td>

                                </tr>

                                <tr>
                                    <td class="taskDesc">Order Date</td>
                                    <td class="taskStatus">
                                        <?php echo e(date('F d, Y', strtotime($orders->updated_at))); ?> |
                                        <?php echo e(date('h:i A', strtotime($orders->updated_at))); ?>


                                    </td>

                                </tr>

                                <tr>
                                    <td class="taskDesc">Order Status</td>
                                    <td class="taskStatus"><?php echo e($orders->order_status); ?></td>

                                </tr>

                                <tr>
                                    <td class="taskDesc">Order Total Amount</td>
                                    <td class="taskStatus">PHP <?php echo e($orders->total_amount); ?></td>

                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    


                    <div class="accordion" id="collapse-group">
                        <div class="accordion-group widget-box">
                            <div class="accordion-heading">
                                <div class="widget-title"> <a data-parent="#collapse-group" href="#collapseGOne" data-toggle="collapse"> <span class="icon"><i class="icon-ok"></i></span>
                                        <h5>Billing Details</h5>
                                    </a> </div>
                            </div>
                            <div class="collapse in accordion-body" id="collapseGOne">
                                <div class="widget-content">
                                     Name: <?php echo e($user_details->f_name); ?><br>
                                    Phone # :<?php echo e($user_details->mobile); ?><br>
                                        Address<br>
                                    Street : <?php echo e($user_details->street); ?><br>
                                    Baranggay : <?php echo e($user_details->baranggay); ?><br>
                                    City : <?php echo e($user_details->city); ?><br>


                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="span6">


                    <div class="widget-box">
                        <div class="widget-title">
                            <h5>Customer Details</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <table class="table table-striped table-bordered">

                                <tbody>
                                <tr>
                                    <td class="taskDesc">Customer Name</td>
                                    <td class="taskStatus"><?php echo e($user_details->f_name); ?>

                                        <?php echo e($user_details->m_name); ?> <?php echo e($user_details->l_name); ?> </td>

                                </tr>
                                <tr>
                                    <td class="taskDesc">Customer Email </td>
                                    <td class="taskStatus"><?php echo e($user_details->email); ?></td>

                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    


                    
                    <div class="widget-box">
                        <div class="widget-title">
                            <h5>Update Order Status</h5>
                        </div>
                        <form action="<?php echo e(url('/admin/update-status')); ?>" method="post"><?php echo e(csrf_field()); ?>

                            
                            <input type="hidden" name="order_id" value="<?php echo e($orders->id); ?>">
                            <table width="100%">
                                <tr>
                                    <td>
                            <select name="status" id="status" class="control-label" required="">

                                <option value="New" <?php if($orders->order_status == "New"): ?> selected="" <?php endif; ?>>New</option>
                                
                                <option value="In Process" <?php if($orders->order_status == "In Process"): ?> selected="" <?php endif; ?>>In Process</option>
                                <option value="Cancelled" <?php if($orders->order_status == "Cancelled"): ?> selected="" <?php endif; ?>>Cancelled</option>
                                <option value="Paid" <?php if($orders->order_status == "Paid"): ?> selected="" <?php endif; ?>>Paid</option>

                            </select>
                                    </td>
                                    <td>
                            <input type="submit" value="Update">
                                    </td>
                            </table>
                        </form>
                        <div class="widget-content nopadding">

                        </div>
                    </div>
                    




                </div>

                <div class="row-fluid">

                    <table id="example" class="table table-striped table-bordered" style="width:100%;">
                        <thead>
                        <tr>



                            
                            <th>Ordered Products</th>
                            <th> Quantity</th>
                            <th> Price</th>
                            <th> Subtotal</th>
                        </tr>
                        </thead>
                        <tbody>
                        

                        
                        <?php $__currentLoopData = $orders4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $orderss->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $display): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($display->product_name); ?></td>
                                
                                
                                

                                <td> <?php echo e($display->pivot->quantity); ?></td>
                                    
                                <td> <?php echo e($display->pivot->price); ?></td>
                                <td><?php echo e(($display->pivot->quantity)*($display->pivot->price)); ?> <td>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <Td>Total Amout:    <?php echo e($orders->total_amount); ?></Td>
                                </tr>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
            <hr>

        </div>
    </div>
    <!--main-container-part-->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout.admin_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>