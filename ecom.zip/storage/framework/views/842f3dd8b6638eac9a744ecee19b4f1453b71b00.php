<?php $__env->startSection('content'); ?>

    <section id="cart_items">
        <div class="container">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li class="active">Order Review</li>
                </ol>
            </div><!--/breadcrums-->




            <div class="shopper-informations">

                <div class="row">
                    <div class="col-sm-3">
                        <div class="shopper-info">

                            
                            
                            
                            
                            
                            
                            
                            
                            
                        </div>
                    </div>


                    <div class="col-sm-5 clearfix" style="margin-top: 20px;margin-left: -20px;margin-bottom: 50px;">

                        <div class="bill-to">
                            <p>Billing Details</p>
                            <div class="form-one">

                                <div class="form-group">
                                    Email : <?php echo e($user_details->email); ?>

                                </div>
                                <div class="form-group">
                                    First Name : <?php echo e($user_details->f_name); ?>

                                    
                                </div>
                                <div class="form-group">
                                   Middle Name : <?php echo e($user_details->m_name); ?>

                                    
                                </div>
                                <div class="form-group">
                                    Last Name : <?php echo e($user_details->l_name); ?>

                                    
                                </div>

                                <div class="form-group">
                                    Street : <?php echo e($user_details->street); ?>


                                </div>

                                <div class="form-group">
                                    Baranggay : <?php echo e($user_details->baranggay); ?>

                                </div>

                                <div class="form-group">
                                    City : <?php echo e($user_details->city); ?>

                                </div>
                                <div class="form-group">
                                    Phone number : <?php echo e($user_details->mobile); ?>

                                </div>




                            </div>
                        </div>

                    </div>
                    
                    
                    
                    <div class="col-sm-4">
                        <div class="order-message">
                            
                            
                            
                        </div>
                    </div>
                </div>
            </div>


            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            
            

            
            <div class="review-payment" style="margin-top:20px;">
                <h2>Cart List </h2>
            </div>

                <div class="table-responsive cart_info" style="margin-top: -15px;" >
                    <table class="table table-condensed">
                        <thead>
                        <tr class="cart_menu">
                            <td class="image">Item</td>
                            <td class="description"></td>
                            <td class="price">Price</td>
                            <td class="quantity">Quantity</td>
                            <td class="total">Total</td>
                            <td></td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $total_amount = 0; ?>
                        <?php $__currentLoopData = $userCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $cart->cartprod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="cart_product">
                                    <a href=""><img style="width:100px;" src="<?php echo e(asset('images/backend_images/products/small/'.$carts->image)); ?>" alt=""></a>
                                </td>
                                <td class="cart_description">
                                    <h4><a href=""><?php echo e($carts->product_name); ?></a></h4>
                                    <p>Code:<?php echo e($carts->product_code); ?> | Size:<?php echo e($carts->size); ?> <?php echo e($carts->measurement); ?></p>

                                </td>
                                <td class="cart_price">
                                    <p>P<?php echo e($carts->price); ?></p>
                                    <input type="hidden" value="<?php echo e($carts->price); ?>">
                                </td>
                                <td class="cart_price">
                                    <p><?php echo e($cart->quantity); ?></p>
                                </td>
                                <td class="cart_total">
                                    <p class="cart_total_price">P<?php echo e($carts->price*$cart->quantity); ?></p>
                                    
                                </td>
                                <td class="cart_delete">
                                    <a class="cart_quantity_delete" href="<?php echo e(url('/cart/delete-product/'.$cart->id)); ?>"><i class="fa fa-times"></i></a>
                                </td>
                            </tr>

                            <?php $total_amount = $total_amount + ($carts->price*$cart->quantity); ?>
                            <?php ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td colspan="4">&nbsp;</td>
                            <td colspan="2">
                                <table class="table table-condensed total-result">
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    <tr>
                                        <td>Total</td>
                                        <td><span>P<?php echo $total_amount; ?></span></td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                        </tbody>

                    </table>
                </div>
            <form id="accountForm" name="accountForm" action="<?php echo e(url('ty')); ?>" method="post" ><?php echo e(csrf_field()); ?>

                <div class="payment-options">
                    <input type="hidden" name="total" value="<?php echo e($total_amount); ?>">
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    


                    <button type="submit" class="btn btn-default" style="background-color: orange;color: whitesmoke;">Confirm Order</button>
                </div>
            </form>
        </div>

        </form>
    </section> <!--/#cart_items-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>