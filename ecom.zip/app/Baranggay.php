<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Baranggay extends Model
{
    //
}
